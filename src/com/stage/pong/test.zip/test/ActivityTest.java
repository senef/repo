package com.stage.pong.test;

import android.app.Activity;
import android.os.Bundle;

public class ActivityTest extends Activity{
	
	private TestAudio TA;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
	}
	
	

}
